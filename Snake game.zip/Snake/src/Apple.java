
public class Apple {
    int x;
    int y;
    boolean healthy;
    Apple(int x, int y, boolean healthy){
        this.x=x;
        this.y=y;
        this.healthy=healthy;
    }

}
